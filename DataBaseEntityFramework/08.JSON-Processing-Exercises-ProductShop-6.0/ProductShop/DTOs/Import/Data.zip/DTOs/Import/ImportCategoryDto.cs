﻿namespace ProductShop.DTOs.Import;

public class ImportCategoryDto
{
    public string Name { get; set; } = null!;
}
