﻿
namespace P01_StudentSystem;
using Microsoft.EntityFrameworkCore.SqlServer;
public class StartUp
{
    static void Main(string[] args)
    {
        Console.WriteLine("Hello World!");
    }
}