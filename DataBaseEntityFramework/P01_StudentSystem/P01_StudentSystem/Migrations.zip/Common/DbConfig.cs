﻿namespace P01_StudentSystem.Common;

public class DbConfig
{
    public const string ConnectionString =
            @"Server=TSVTOSLAV\SQLEXPRESS;Database=StudentSystem;
             Integrated Security=True; Encrypt=False";
}
