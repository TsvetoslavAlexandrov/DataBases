﻿namespace P01_StudentSystem.Models.Enum;

public enum ResourceType
{
    Video,
    Presentation,
    Document,
    Other
}
