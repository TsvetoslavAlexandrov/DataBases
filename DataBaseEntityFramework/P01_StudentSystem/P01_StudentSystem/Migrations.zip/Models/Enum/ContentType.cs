﻿namespace P01_StudentSystem.Models.Enum;

public enum ContentType
{
    Application,
    Pdf,
    Zip
}
